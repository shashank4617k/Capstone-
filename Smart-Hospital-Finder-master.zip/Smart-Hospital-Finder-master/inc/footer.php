
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   height: 8%;
   width: 100%;
   background-color: #232528;
   color: white;
   text-align: center;
}
</style>
</head>
<body>


<div class="footer">
  <p style= "text-align:center;">&copy;
    <a href = "https://rana.akash0003@gmail.com">Copyright</a> RRI, CSE-411-PROJECT-EWU.</p>
</div>

</body>
</html> 
