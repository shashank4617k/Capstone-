	<!-- Database Connection -->
 

	<!-- Header File -->
<?php include"inc/header.php";?>

    <!-- Navigation -->
<?php include"inc/nav.php";?>
    
    <!-- full slider -->
<?php include"inc/slider.php";?>  
	
	<!-- Section -->
<?php include"inc/sections.php";?>
    
    <!-- Footer -->
<?php include"inc/footer.php";?>




